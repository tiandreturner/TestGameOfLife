### Starter setup for phase 1 of the GameOfLive
